import{a as e,d as t,f as n,i as r,l as i,o as a,u as o}from"./phaze-CveGO6-s.js";function s(e){return e.getTotalLength()}function c(e,t){let n=s(e);e.style.strokeDasharray=`${n} ${n}`,e.style.strokeDashoffset=`${n*(1-t)}`}var l=4,u=.001,d=10,f=1e-7,p=11,m=1/10,h=(e,t)=>1-3*t+3*e,g=(e,t)=>3*t-6*e,_=e=>3*e,v=(e,t,n)=>((h(t,n)*e+g(t,n))*e+_(t))*e,y=(e,t,n)=>3*h(t,n)*e*e+2*g(t,n)*e+_(t);function b(e,t,n,r){if(e===t&&n===r)return e=>e;let i=new Float32Array(p);for(let t=0;t<p;++t)i[t]=v(t*m,e,n);function a(t){let r=0,a=1;for(;a!==10&&i[a]<=t;++a)r+=m;--a;let o=(t-i[a])/(i[a+1]-i[a]),s=r+o*m,c=y(s,e,n);if(c>=u){for(let r=0;r<l;++r){let r=y(s,e,n);if(r===0)return s;let i=v(s,e,n)-t;s-=i/r}return s}if(c===0)return s;{let i=r,a=r+m,o=0,s,c;do c=i+(a-i)/2,s=v(c,e,n)-t,s>0?a=c:i=c;while(Math.abs(s)>f&&++o<d);return c}}return e=>e===0||e===1?e:v(a(e),t,r)}function x(e,t,n,r,i,a=0){let o=r-i,s=a,c=t/(2*Math.sqrt(e*n)),l=Math.sqrt(e/n);return e=>{let t,n;if(c<1){let r=l*Math.sqrt(1-c*c),a=Math.exp(-c*l*e);t=i+a*(o*Math.cos(r*e)+(c*l*o+s)/r*Math.sin(r*e));let u=-c*l*a,d=-r*o*Math.sin(r*e)+(c*l*o+s)*Math.cos(r*e);n=u*(o*Math.cos(r*e)+(c*l*o+s)/r*Math.sin(r*e))+a*d}else if(c===1){let r=Math.exp(-l*e);t=i+r*(o+(l*o+s)*e),n=-l*r*(o+(l*o+s)*e)+r*(l*o+s)}else{let r=-l*(c-Math.sqrt(c*c-1)),a=-l*(c+Math.sqrt(c*c-1)),u=(s-r*o)/(a-r),d=o-u;t=i+d*Math.exp(r*e)+u*Math.exp(a*e),n=d*r*Math.exp(r*e)+u*a*Math.exp(a*e)}return{position:t,velocity:n}}}function S(e){return typeof e==`function`&&typeof e.set==`function`&&typeof e.subscribe==`function`}function C(e){return S(e)?e.current():e.value===void 0?0:e.value}function w(e,t){return S(e)&&typeof e.set==`function`?(e.set(t),!0):e.value!==void 0&&(e.value=t,!0)}function T(e){let{visualDuration:t,bounce:n=0,mass:r=1}=e;if(t!==void 0){let e=2*Math.PI/t;return{stiffness:e*e*r,damping:2*r*e*(1-n),mass:r}}return{stiffness:e.stiffness??100,damping:e.damping??30,mass:r}}var E=new Map,D=!1;function O(e){if(E.size===0){D=!1;return}let t=!1;for(let n of E.values()){if(n.id===-1||(t=!0,e<n.startTime))continue;let{restDelta:r=.001,restSpeed:i,duration:a=.3,repeat:o=0,repeatType:s=`loop`}=n.options;n.lastTime=e;let c=!1,l=0,u=0;if(n.useSpring&&n.springSolver){let t=(e-n.startTime)/1e3,a=n.springSolver(t);l=a.position,u=a.velocity;let o=i??r;c=Math.abs(l-n.targetValue)<r&&Math.abs(u)<o,c&&(l=n.targetValue)}else{let t=(e-n.startTime)/1e3,r=Math.min(t/a,1),i=n.easeFn?n.easeFn(r):r;l=n.currentValue+(n.targetValue-n.currentValue)*i,r>=1&&(c=!0)}if(k(n.target,l,n.keyframe),n.options.onUpdate&&n.options.onUpdate({start:n.currentValue,target:n.targetValue,startTime:n.startTime,velocity:u,stiffness:0,damping:0,mass:1}),n.currentValue=l,n.velocity=u,c){if(o===1/0||o>0){if(n.startTime=e,o!==1/0&&n.options.repeat--,s===`reverse`){let e=n.currentValue;if(n.currentValue=n.targetValue,n.targetValue=e,n.useSpring){let{stiffness:e,damping:t,mass:r}=T(n.options);n.springSolver=x(e,t,r,n.currentValue,n.targetValue,0)}}else if(n.useSpring){let{stiffness:e,damping:t,mass:r}=T(n.options);n.springSolver=x(e,t,r,n.currentValue,n.targetValue,0)}}else n.id=-1}}t?requestAnimationFrame(O):D=!1}function k(e,t,n){if(!w(e,t)&&(e instanceof HTMLElement||e instanceof SVGElement)){let r=e;if(r instanceof SVGPathElement||r.tagName===`path`||r.tagName===`circle`)c(r,t);else if(typeof n==`string`&&(n===`visible`||n===`hidden`)){let e=t>=.5;r.style.visibility=e?`visible`:`hidden`}else r.style.opacity=t.toString()}}function A(e,t,n={}){if(typeof window>`u`)return null;let r=S(e),i=!r&&e.value!==void 0,a=r||i,o=e.remote===!0,s=e instanceof HTMLElement||e instanceof SVGElement;if(!a&&!s&&!o)return null;let c=typeof t==`number`?t:+(t===`visible`),l=n.stiffness!==void 0||n.damping!==void 0,u=E.get(e);if(u){let e=performance.now();if(u.id!==-1&&e>u.startTime){if(u.useSpring&&u.springSolver){let t=(e-u.startTime)/1e3,{position:n,velocity:r}=u.springSolver(t);u.currentValue=n,u.velocity=r}else{let t=u.options.duration||.3,n=(e-u.startTime)/1e3,r=Math.min(n/t,1);u.currentValue+=(u.targetValue-u.currentValue)*r,u.velocity=0}}let r=u.id===-1||u.targetValue!==c;if(u.targetValue=c,u.options={...u.options,...n},u.keyframe=t,u.useSpring=l,r){if(u.id=e,u.lastTime=e,u.startTime=e+(n.delay||0)*1e3,!l){let e=u.options.ease;u.easeFn=e?Array.isArray(e)&&e.length===4?b(e[0],e[1],e[2],e[3]):e:void 0}if(l){let{stiffness:e,damping:t,mass:r}=T(u.options);u.springSolver=x(e,t,r,u.currentValue,c,u.velocity),o&&n.onUpdate&&n.onUpdate({start:u.currentValue,target:c,startTime:u.startTime,velocity:u.velocity,stiffness:e,damping:t,mass:r})}!D&&!o&&(D=!0,requestAnimationFrame(O))}return}let d=a?C(e):o?e.value:0,f=performance.now(),{stiffness:p,damping:m,mass:h}=T(n),g=n.ease,_=!l&&g?Array.isArray(g)&&g.length===4?b(g[0],g[1],g[2],g[3]):g:void 0,v={target:e,id:f,targetValue:c,currentValue:d,velocity:n.velocity??0,startTime:f+(n.delay||0)*1e3,lastTime:f,options:n,useSpring:l,easeFn:_,keyframe:t,springSolver:l?x(p,m,h,d,c,n.velocity??0):void 0};E.set(e,v),o&&n.onUpdate&&v.useSpring&&n.onUpdate({start:d,target:c,startTime:v.startTime,velocity:0,stiffness:p,damping:m,mass:h}),!D&&!o&&(D=!0,requestAnimationFrame(O))}function ee(e){let t=E.get(e);t&&(t.id=-1)}var j=class{_value;_changeSubscribers=[];set;constructor(e){this._value=e,this.set=e=>this._set(e)}get value(){return this._value}set value(e){this._set(e)}get(){return this._value}_set(e){if(this._value===e)return;this._value=e;let t=this._changeSubscribers.slice();for(let n=0;n<t.length;n++)t[n](e)}on(e,t){return this._changeSubscribers.push(t),()=>{this._changeSubscribers.splice(this._changeSubscribers.indexOf(t),1)}}destroy(){this._changeSubscribers.length=0}},te=e=>e instanceof j?e.get():e.current(),ne=(e,t)=>e instanceof j?e.on(`change`,t):e.subscribe(t);function re(e,t,r,i){let a=t.indexOf(`:`);if(a===-1)throw Error(`photonProp: channel "${t}" must be of the form "<kind>:<name>" — e.g. "style:transform" or "attr:d".`);let o=t.slice(0,a),s=t.slice(a+1);if(typeof e==`function`){n(()=>{let t=e();t&&ae(t,o,s,r,i)});return}ae(e,o,s,r,i)}var ie={"translate-x":e=>({prop:`translate`,value:`${e} 0`}),"translate-y":e=>({prop:`translate`,value:`0 ${e}`}),"translate-z":e=>({prop:`translate`,value:`0 0 ${e}`})};function ae(e,t,r,i,a){let s=typeof a==`string`?e=>String(e)+a:typeof a==`function`?a:null,c;switch(t){case`style`:{let t=ie[r];c=t?n=>{let r=t(s?s(n):String(n));e.style[r.prop]=r.value}:t=>{e.style[r]=s?s(t):t};break}case`attr`:c=t=>{e.setAttribute(r,s?s(t):String(t))};break;default:throw Error(`photonProp: unknown channel kind "${t}". Expected "style" or "attr".`)}if(i instanceof j){c(i.get());let e=i.on(`change`,c);o(e)}else n(()=>c(i()))}function oe(e,t,n={}){A(e,t,n),o(()=>ee(e))}function se(e){return new j(e)}var ce={stiffness:500,damping:100,mass:3,restSpeed:.5,restDelta:.01,bounce:0},le={x:{channel:`style:translate-x`,unit:`px`},y:{channel:`style:translate-y`,unit:`px`},z:{channel:`style:translate-z`,unit:`px`},rotate:{channel:`style:rotate`,unit:`deg`},opacity:{channel:`style:opacity`},scale:{channel:`style:scale`}};function ue(e,t={}){let n=te(e),r=new j(n);oe(r,n,t);let i=ne(e,e=>{oe(r,e,t)});return o(i),r}function de(e,n){let r=n(),i=`to`in r?r.to:r,a=`to`in r?r.springs:void 0;for(let r of Object.keys(i)){let i=le[r];if(!i)throw Error(`use:spring: unknown target key "${String(r)}". Supported keys: ${Object.keys(le).join(`, `)}.`);let o=ue(t(()=>{let e=n();return(`to`in e?e.to:e)[r]??0}),a?.[r]??ce);i.unit?re(e,i.channel,o,i.unit):re(e,i.channel,o)}}function fe(e,t){return typeof Element<`u`&&e instanceof Element?de(e,t):ue(e,t)}var pe=i(),me=i(null,{name:`fabric:gpu`}),he=i(),ge={current:{}},_e={current:{}},ve={current:{x:0,y:0,z:8}},ye={current:new Map},be={current:null},xe={current:null};function M(){return{cameraRef:ge,sceneRef:_e,camPosRef:ve,shapesRef:ye,canvas:pe,gpuError:he,gpu:me,gpuRef:be,initialPointerRef:xe}}function Se(e){pe.set(e)}function Ce(e){he.set(e)}function we(e,t){Object.assign(ge.current,e),Object.assign(_e.current,t)}function N(){return new Float32Array(16)}function Te(e){return e.fill(0),e[0]=e[5]=e[10]=e[15]=1,e}function P(e,t,n){for(let r=0;r<4;r++)for(let i=0;i<4;i++){let a=0;for(let e=0;e<4;e++)a+=t[e*4+r]*n[i*4+e];e[i*4+r]=a}return e}function Ee(e,t,n,r,i,a=1){Te(e);let o=1/Math.tan(t*Math.PI/360)*a;return e[0]=o/n,e[5]=o,e[10]=-(i+r)/(i-r),e[11]=-1,e[14]=-(2*i*r)/(i-r),e[15]=0,e}function De(e,t,n,r,i,a,o){let s=i-t,c=a-n,l=o-r,u=Math.sqrt(s*s+c*c+l*l);s/=u,c/=u,l/=u;let d=c*0-l*1,f=l*0-s*0,p=s*1-c*0,m=Math.sqrt(d*d+f*f+p*p);d/=m,f/=m,p/=m;let h=f*l-p*c,g=p*s-d*l,_=d*c-f*s;return Te(e),e[0]=d,e[4]=f,e[8]=p,e[12]=-(d*t+f*n+p*r),e[1]=h,e[5]=g,e[9]=_,e[13]=-(h*t+g*n+_*r),e[2]=-s,e[6]=-c,e[10]=-l,e[14]=s*t+c*n+l*r,e}function Oe(e,t,n,r,i,a,o){let s=Math.cos(i),c=Math.sin(i),l=Math.cos(a),u=Math.sin(a),d=Math.cos(o),f=Math.sin(o);return e[0]=l*d,e[4]=-l*f,e[8]=u,e[12]=t,e[1]=c*u*d+s*f,e[5]=-c*u*f+s*d,e[9]=-c*l,e[13]=n,e[2]=-s*u*d+c*f,e[6]=s*u*f+c*d,e[10]=s*l,e[14]=r,e[3]=0,e[7]=0,e[11]=0,e[15]=1,e}function ke(e,t){let n=t[0],r=t[1],i=t[2],a=t[3],o=t[4],s=t[5],c=t[6],l=t[7],u=t[8],d=t[9],f=t[10],p=t[11],m=t[12],h=t[13],g=t[14],_=t[15],v=n*s-r*o,y=n*c-i*o,b=n*l-a*o,x=r*c-i*s,S=r*l-a*s,C=i*l-a*c,w=u*h-d*m,T=u*g-f*m,E=u*_-p*m,D=d*g-f*h,O=d*_-p*h,k=f*_-p*g,A=v*k-y*O+b*D+x*E-S*T+C*w;return A?(A=1/A,e[0]=(s*k-c*O+l*D)*A,e[1]=(i*O-r*k-a*D)*A,e[2]=(h*C-g*S+_*x)*A,e[3]=(f*S-d*C-p*x)*A,e[4]=(c*E-o*k-l*T)*A,e[5]=(n*k-i*E+a*T)*A,e[6]=(g*b-m*C-_*y)*A,e[7]=(u*C-f*b+p*y)*A,e[8]=(o*O-s*E+l*w)*A,e[9]=(r*E-n*O-a*w)*A,e[10]=(m*S-h*b+_*v)*A,e[11]=(d*b-u*S-p*v)*A,e[12]=(s*T-o*D-c*w)*A,e[13]=(n*D-r*T+i*w)*A,e[14]=(h*y-m*x-g*v)*A,e[15]=(u*x-d*y+f*v)*A,e):null}var Ae=`struct SimUniforms {
  time:          f32,
  curlFreq:      f32,
  curlAmplitude: f32,
  maxDistance:   f32,
  numObjects:    f32
}

@group(0) @binding(0) var<storage, read> originalPositions: array<vec4f>;
@group(0) @binding(1) var<storage, read_write> currentPositions: array<vec4f>;
@group(0) @binding(2) var<uniform> sim: SimUniforms;

fn mod289v3(x: vec3f) -> vec3f {
  return x - floor(x * (1.0 / 289.0)) * 289.0;
}

fn mod289v4(x: vec4f) -> vec4f {
  return x - floor(x * (1.0 / 289.0)) * 289.0;
}

fn permute4(x: vec4f) -> vec4f {
  return mod289v4(((x * 34.0) + 1.0) * x);
}

fn taylorInvSqrt4(r: vec4f) -> vec4f {
  return 1.79284291400159 - 0.85373472095314 * r;
}

fn snoise(v: vec3f) -> f32 {
  let C = vec2f(1.0 / 6.0, 1.0 / 3.0);
  let D = vec4f(0.0, 0.5, 1.0, 2.0);

  
  var i = floor(v + dot(v, C.yyy));
  let x0 = v - i + dot(i, C.xxx);

  
  let g = step(x0.yzx, x0.xyz);
  let l = 1.0 - g;
  let i1 = min(g.xyz, l.zxy);
  let i2 = max(g.xyz, l.zxy);

  
  
  
  let x1 = x0 - i1 + C.xxx;
  let x2 = x0 - i2 + C.yyy;
  let x3 = x0 - D.yyy;

  
  i = mod289v3(i);
  let p = permute4(
    permute4(
      permute4(i.z + vec4f(0.0, i1.z, i2.z, 1.0)) 
      + i.y + vec4f(0.0, i1.y, i2.y, 1.0)
    ) 
    + i.x + vec4f(0.0, i1.x, i2.x, 1.0)
  );

  
  
  let n_ = 0.142857142857; 
  let ns = n_ * D.wyz - D.xzx;

  let j = p - 49.0 * floor(p * ns.z * ns.z); 

  let x_ = floor(j * ns.z);
  let y_ = floor(j - 7.0 * x_); 

  let xv = x_ * ns.x + ns.yyyy;
  let yv = y_ * ns.x + ns.yyyy;

  let h = 1.0 - abs(xv) - abs(yv);

  let b0 = vec4f(xv.xy, yv.xy);
  let b1 = vec4f(xv.zw, yv.zw);

  let s0 = floor(b0) * 2.0 + 1.0;
  let s1 = floor(b1) * 2.0 + 1.0;
  let sh = -step(h, vec4f(0.0));

  let a0 = b0.xzyw + s0.xzyw * sh.xxyy;
  let a1 = b1.xzyw + s1.xzyw * sh.zzww;

  var p0 = vec3f(a0.xy, h.x);
  var p1 = vec3f(a0.zw, h.y);
  var p2 = vec3f(a1.xy, h.z);
  var p3 = vec3f(a1.zw, h.w);

  
  let norm = taylorInvSqrt4(vec4f(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3)));
  p0 *= norm.x;
  p1 *= norm.y;
  p2 *= norm.z;
  p3 *= norm.w;

  
  var m = max(0.6 - vec4f(dot(x0, x0), dot(x1, x1), dot(x2, x2), dot(x3, x3)), vec4f(0.0));
  m *= m;
  return 42.0 * dot(m * m, vec4f(dot(p0, x0), dot(p1, x1), dot(p2, x2), dot(p3, x3)));
}

fn snoiseVec3(x: vec3f) -> vec3f {
  return vec3f(
    snoise(x),
    snoise(vec3f(x.y - 19.1, x.z + 33.4, x.x + 47.2)),
    snoise(vec3f(x.z + 74.2, x.x - 124.5, x.y + 99.4))
  );
}

fn curlNoise(p: vec3f) -> vec3f {
  let e = 0.1;
  let dx = vec3f(e, 0.0, 0.0);
  let dy = vec3f(0.0, e, 0.0);
  let dz = vec3f(0.0, 0.0, e);

  let px0 = snoiseVec3(p - dx);
  let px1 = snoiseVec3(p + dx);
  let py0 = snoiseVec3(p - dy);
  let py1 = snoiseVec3(p + dy);
  let pz0 = snoiseVec3(p - dz);
  let pz1 = snoiseVec3(p + dz);

  let xc = py1.z - py0.z - pz1.y + pz0.y;
  let yc = pz1.x - pz0.x - px1.z + px0.z;
  let zc = px1.y - px0.y - py1.x + py0.x;

  return normalize(vec3f(xc, yc, zc) * (1.0 / (2.0 * e)));
}

const WG_X_STRIDE: u32 = 16384u;

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3u) {
  let index = id.x + id.y * WG_X_STRIDE;
  
  if (index >= arrayLength(&originalPositions)) {
    return;
  }

  let pos = originalPositions[index].xyz;
  let t = sim.time * 0.015;

  
  var n = curlNoise(pos * sim.curlFreq + t);
  n += curlNoise(n * sim.curlFreq * 2.0) * 0.5;
  n += curlNoise(n * sim.curlFreq * 4.0) * 0.25;
  n += curlNoise(n * sim.curlFreq * 8.0) * 0.125;
  n += curlNoise(n * sim.curlFreq * 16.0) * 0.0625;

  
  let tar = pos + n * sim.curlAmplitude;
  let d = clamp(length(pos - tar) / sim.maxDistance, 0.0, 1.0);
  
  
  currentPositions[index] = vec4f(mix(pos, tar, pow(d, 5.0)), 1.0);
}`,je=`struct RenderUniforms {
  mvpMatrix:           mat4x4f,    
  modelViewMatrix:     mat4x4f,    
  color:               vec4f,      
  focusColor:          vec4f,      
  cameraPos:           vec4f,      
  pointerAndViewport:  vec4f,      
  params0:             vec4f,      
  params1:             vec4f,      
  params2:             vec4f,      
  params3:             vec4f,      
  params4:             vec4f,      
  vpMatrix:            mat4x4f,    
  viewMatrix:          mat4x4f,    
  extraParams:         vec4f       
}

@group(0) @binding(0) var<storage, read> positions: array<vec4f>;
@group(0) @binding(1) var<uniform> uni: RenderUniforms;
@group(0) @binding(2) var<storage, read> plyColors: array<vec4f>;

struct VertexOutput {
  @builtin(position) position:    vec4f,
  @location(0)       vUv:         vec2f,
  @location(1)       vAngle:      f32,
  @location(2)       vForeshorten: f32,
  @location(3)       vDistance:    f32,
  @location(4)       vColor:       vec4f
}

const quadOffsets = array<vec2f, 6>(
  vec2f(-0.5, -0.5), vec2f(0.5, -0.5), vec2f(0.5, 0.5),
  vec2f(-0.5, -0.5), vec2f(0.5, 0.5),  vec2f(-0.5, 0.5)
);

const quadUVs = array<vec2f, 6>(
  vec2f(0, 0), vec2f(1, 0), vec2f(1, 1),
  vec2f(0, 0), vec2f(1, 1), vec2f(0, 1)
);

fn gmod(x: f32, y: f32) -> f32 {
  return x - y * floor(x / y);
}

@vertex
fn vs(
  @builtin(vertex_index)   vIdx: u32,
  @builtin(instance_index) iIdx: u32
) -> VertexOutput {
  var out: VertexOutput;
  var pos = positions[iIdx].xyz;
  
  
  
  
  
  
  let gridScale = uni.params2.w / max(uni.pointerAndViewport.w, 1.0);
  pos.x = pos.x * gridScale;
  pos.y = pos.y * gridScale;

  
  let pointer      = uni.pointerAndViewport.xy;
  let viewport     = uni.pointerAndViewport.zw;
  let pointSize    = uni.params0.x;
  let focus        = uni.params0.y;
  let blur         = uni.params0.z;
  let cameraFov    = uni.params1.x;
  let cameraZoom   = uni.params1.y;
  let aspect       = uni.params1.z;
  let warpStrength = uni.params1.w;
  let warpRadius   = uni.params2.x;
  let pointerZ     = uni.params2.y;
  let pointerFall  = uni.params2.z;
  let useSlots     = uni.params3.y > 0.5;
  let slotSize     = uni.params4.x;
  let rigMode      = i32(round(uni.params4.y));

  
  if (rigMode == 2) {
    let d = distance(pos.xy, pointer * 10.0);
    pos.z += smoothstep(warpRadius, 0.0, d) * warpStrength;
  }

  
  let mvPos = uni.modelViewMatrix * vec4f(pos, 1.0);
  let vDist = abs(focus - (-mvPos.z));
  var clipPos = uni.mvpMatrix * vec4f(pos, 1.0);

  
  var pxSize = pointSize + vDist * blur;
  if (useSlots) { pxSize *= slotSize; }

  
  let corner = quadOffsets[vIdx] * pxSize;
  clipPos.x += (corner.x * 2.0 / viewport.x) * clipPos.w;
  clipPos.y += (corner.y * 2.0 / viewport.y) * clipPos.w;

  var vAngle: f32       = 0.0;
  var vForeshorten: f32 = 1.0;

  
  if (rigMode == 1) {
    
    let targetDist = uni.cameraPos.z - pointerZ;
    let viewScale  = 2.0 * targetDist * tan(cameraFov * 0.5 * 3.14159265 / 180.0) / cameraZoom;
    let vTarget    = vec3f(pointer.x * aspect * viewScale * 0.5, pointer.y * viewScale * 0.5, -targetDist);
    let vDir       = vTarget - mvPos.xyz;
    let angMouse   = atan2(vDir.y, vDir.x);
    
    let mvOrigin   = (uni.modelViewMatrix * vec4f(0.0, 0.0, 0.0, 1.0)).xyz;
    let vDirOrig   = mvOrigin - mvPos.xyz;
    let angOrigin  = atan2(vDirOrig.y, vDirOrig.x);
    
    var diff = angMouse - angOrigin;
    diff = gmod(diff + 3.14159265, 6.2831853) - 3.14159265;
    
    var falloff = 1.0;
    if (pointerFall > 0.0) {
      let d2 = length(vTarget.xy - mvPos.xy);
      falloff = 1.0 / (1.0 + pow(d2 / pointerFall, 2.0));
    }
    vAngle = angOrigin + diff * falloff;
  } else if (rigMode == 3) {
    
    let ndcPos = clipPos.xy / clipPos.w;
    vAngle = atan2(-ndcPos.y, -ndcPos.x);
  } else {
    
    let gridNorm = (uni.modelViewMatrix * vec4f(0, 0, 1, 0)).xyz;
    let sLen = length(gridNorm.xy);
    if (sLen < 0.001) {
      vAngle = 1.5707963;
      vForeshorten = 0.0;
    } else {
      vAngle = atan2(gridNorm.y, gridNorm.x);
      vForeshorten = sLen;
    }
  }

  let usePlyColor = uni.params4.z > 0.5;
  out.position     = clipPos;
  out.vUv          = quadUVs[vIdx];
  out.vAngle       = vAngle;
  out.vForeshorten = vForeshorten;
  out.vDistance    = vDist;
  out.vColor       = select(uni.color, plyColors[iIdx], usePlyColor);
  
  return out;
}

@fragment
fn fs(in: VertexOutput) -> @location(0) vec4f {
  let useSlots     = uni.params3.y > 0.5;
  let slotRadius   = uni.params3.z;
  let slotLength   = uni.params3.w;
  let highlightFoc = uni.params3.x > 0.5;
  
  let cxy = 2.0 * in.vUv - 1.0;
  var radialAlpha: f32;

  if (useSlots) {
    
    let s = sin(in.vAngle);
    let c = cos(in.vAngle);
    var p = vec2f(c * cxy.x - s * cxy.y, s * cxy.x + c * cxy.y);
    
    
    p.x -= clamp(p.x, -slotLength * in.vForeshorten, 0.0);
    
    let d = length(p);
    if (d > slotRadius) { discard; }
    radialAlpha = smoothstep(slotRadius, slotRadius - 0.05, d);
  } else {
    
    let r = dot(cxy, cxy);
    if (r > 1.0) { discard; }
    radialAlpha = smoothstep(1.0, 0.0, sqrt(r));
  }

  
  let depthAlpha = 1.04 - clamp(in.vDistance * 0.5, 0.0, 1.0);
  var finalColor = in.vColor.rgb;

  
  if (highlightFoc) {
    let f = 1.0 - smoothstep(0.0, 1.5, in.vDistance);
    finalColor = mix(in.vColor.rgb, uni.focusColor.rgb, f);
  }

  let alpha = depthAlpha * radialAlpha;
  return vec4f(finalColor * alpha, alpha);
}`;function Me(e){let{device:t,canvasFormat:n}=e,r=t.createBindGroupLayout({entries:[{binding:0,visibility:GPUShaderStage.COMPUTE,buffer:{type:`read-only-storage`}},{binding:1,visibility:GPUShaderStage.COMPUTE,buffer:{type:`storage`}},{binding:2,visibility:GPUShaderStage.COMPUTE,buffer:{type:`uniform`}},{binding:3,visibility:GPUShaderStage.COMPUTE,buffer:{type:`read-only-storage`}}]});e.computePipeline=t.createComputePipeline({layout:t.createPipelineLayout({bindGroupLayouts:[r]}),compute:{module:t.createShaderModule({code:Ae}),entryPoint:`main`}});let i=t.createBindGroupLayout({entries:[{binding:0,visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT,buffer:{type:`read-only-storage`}},{binding:1,visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT,buffer:{type:`uniform`}},{binding:2,visibility:GPUShaderStage.VERTEX,buffer:{type:`read-only-storage`}},{binding:3,visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT,buffer:{type:`read-only-storage`}},{binding:4,visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT,buffer:{type:`read-only-storage`}}]}),a=t.createShaderModule({code:je}),o=t.createPipelineLayout({bindGroupLayouts:[i]});e.renderPipeline=t.createRenderPipeline({layout:o,vertex:{module:a,entryPoint:`vs`},fragment:{module:a,entryPoint:`fs`,targets:[{format:n,blend:{color:{srcFactor:`one`,dstFactor:`one-minus-src-alpha`,operation:`add`},alpha:{srcFactor:`one`,dstFactor:`one-minus-src-alpha`,operation:`add`}}}]},primitive:{topology:`triangle-list`},depthStencil:{format:`depth24plus`,depthWriteEnabled:!1,depthCompare:`always`}})}function Ne(e){let{device:t,computePipeline:n,renderPipeline:r,originalPositionsBuffer:i,currentPositionsBuffer:a,simUniformBuffer:o,renderUniformBuffer:s}=e;e.computeBindGroup=t.createBindGroup({layout:n.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:i}},{binding:1,resource:{buffer:a}},{binding:2,resource:{buffer:o}},{binding:3,resource:{buffer:e.objectsBuffer}}]}),e.gridBuffer&&e.gridComputePipeline&&(e.gridBindGroup=t.createBindGroup({layout:e.gridComputePipeline.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:e.gridBuffer}},{binding:1,resource:{buffer:e.objectsBuffer}},{binding:2,resource:{buffer:o}}]})),e.renderBindGroup=t.createBindGroup({layout:r.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:a}},{binding:1,resource:{buffer:s}},{binding:2,resource:{buffer:e.plyColorsBuffer}},{binding:3,resource:{buffer:e.objectsBuffer}},{binding:4,resource:{buffer:e.gridBuffer||e.objectsBuffer}}]})}function Pe(e,t){let n=new Float32Array(e*e*4);for(let r=0;r<e;r++)for(let i=0;i<e;i++){let a=(r*e+i)*4;n[a]=(r-(e-1)*.5)*t,n[a+1]=(i-(e-1)*.5)*t,n[a+2]=0,n[a+3]=1}return n}function Fe(e,t,n){let{device:r}=e,i=t.resolution??1024,a=t.gridSpacing??.155;e.numParticles=i*i;let o=e.numParticles*4*4;if(e.originalPositionsBuffer&&e.originalPositionsBuffer.destroy(),e.currentPositionsBuffer&&e.currentPositionsBuffer.destroy(),e.plyColorsBuffer&&e.plyColorsBuffer.destroy(),n){e.originalPositionsBuffer=r.createBuffer({size:o,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),e.currentPositionsBuffer=r.createBuffer({size:o,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),e.plyColorsBuffer=r.createBuffer({size:o,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),Ne(e);return}let s=Pe(i,a);e.originalPositionsBuffer=r.createBuffer({size:o,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,mappedAtCreation:!0}),new Float32Array(e.originalPositionsBuffer.getMappedRange()).set(s),e.originalPositionsBuffer.unmap(),e.currentPositionsBuffer=r.createBuffer({size:o,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,mappedAtCreation:!0}),new Float32Array(e.currentPositionsBuffer.getMappedRange()).set(s),e.currentPositionsBuffer.unmap(),e.plyColorsBuffer=r.createBuffer({size:o,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),Ne(e)}var F={},Ie=N();function I(e){if(F[e])return F[e];let t=e.replace(`#`,``);t.length===3&&(t=t[0]+t[0]+t[1]+t[1]+t[2]+t[2]),t.length===6&&(t+=`ff`);let n=[parseInt(t.slice(0,2),16)/255,parseInt(t.slice(2,4),16)/255,parseInt(t.slice(4,6),16)/255,parseInt(t.slice(6,8),16)/255];return F[e]=n,n}function Le(e,t,n,r){let{device:i,simUniformBuffer:a,renderUniformBuffer:o}=e,s=e.simUniformData;s[0]=e.internalTime,s[1]=n.curl??.1,s[2]=(n.amplitude??0)+e.springs.amplitude.get(),s[3]=n.distance??.05,s[4]=e.shapes.size,i.queue.writeBuffer(a,0,s);let c=2*Math.PI*((n.rotationX??0)+e.springs.rotation.get())/360,l=2*Math.PI*((n.rotationY??0)/360),u=2*Math.PI*((n.rotationZ??0)/360);Oe(e.modelMatrix,n.translateX??.4,n.translateY??1,n.translateZ??0,c,l,u),Ee(e.projMatrix,t.fov??60,e.camAspect,.001,1e4,t.zoom??1),De(e.viewMatrix,e.camPos.x,e.camPos.y,e.camPos.z,0,0,0),P(e.modelViewMatrix,e.viewMatrix,e.modelMatrix),P(e.mvpMatrix,e.projMatrix,e.modelViewMatrix);let d=e.renderUniformData;d.set(e.mvpMatrix,0),d.set(e.modelViewMatrix,16);let f=I(n.color??`#000000`),p=I(n.focusColor??`#00ff00`);d[32]=f[0],d[33]=f[1],d[34]=f[2],d[35]=0,d[36]=p[0],d[37]=p[1],d[38]=p[2],d[39]=0,d[40]=e.camPos.x,d[41]=e.camPos.y,d[42]=e.camPos.z,d[43]=0,d[44]=e.pointer.x,d[45]=e.pointer.y,d[46]=e.canvasWidth*e.pixelRatio,d[47]=e.canvasHeight*e.pixelRatio,d[48]=n.pointsize??8,d[49]=n.focus??10,d[50]=(5.6-(n.aperture??5.6))*9,d[51]=n.sdfEpsilon??1e-4,d[52]=t.fov??60,d[53]=t.zoom??1,d[54]=e.canvasWidth/e.canvasHeight,d[55]=t.warpStrength??3,d[56]=t.warpRadius??4,d[57]=t.pointerZ??0,d[58]=t.pointerFalloff??0,d[59]=e.gridScaleBaseHeight,d[60]=+!!n.highlightFocus,d[61]=+!!n.useSlots,d[62]=n.slotRadius??.05,d[63]=n.slotLength??1,d[64]=n.slotSize??10,d[65]=t.rigMode??0,d[66]=+!!n.usePlyColor,d[67]=e.shapes.size,P(Ie,e.projMatrix,e.viewMatrix),d.set(Ie,68),d.set(e.viewMatrix,84),d[100]=n.sdfEpsilon??1e-4,d[101]=n.maxSteps??100,d[102]=+!!n.debugMode,d[103]=0,d[104]=n.lodScaling??0,d[105]=n.edgeSoftness??1,d[106]=n.stepRelaxation??1,d[107]=0;let m=e.fastEffectConfig;if(m){if(m.glow){let e=I(m.glow.color??`#ffffff`);d[108]=e[0],d[109]=e[1],d[110]=e[2],d[111]=e[3],d[116]=typeof m.glow.intensity==`number`?m.glow.intensity:m.glow.intensity?.get?.()??0,d[117]=typeof m.glow.radius==`number`?m.glow.radius:m.glow.radius?.get?.()??.3}else d[108]=0,d[109]=0,d[110]=0,d[111]=0,d[116]=0,d[117]=.3;if(m.outline){let e=I(m.outline.color??`#ffffff`),t=m.outline.opacity==null?1:typeof m.outline.opacity==`number`?m.outline.opacity:m.outline.opacity?.get?.()??1;d[112]=e[0],d[113]=e[1],d[114]=e[2],d[115]=e[3]*t,d[118]=typeof m.outline.thickness==`number`?m.outline.thickness:m.outline.thickness?.get?.()??0}else d[112]=0,d[113]=0,d[114]=0,d[115]=0,d[118]=0;d[119]=1}else d[108]=0,d[109]=0,d[110]=0,d[111]=0,d[112]=0,d[113]=0,d[114]=0,d[115]=0,d[116]=0,d[117]=.3,d[118]=0,d[119]=0;if(d[120]=+!!n.enableReflection,d[121]=e.internalTime,d[122]=0,d[123]=0,i.queue.writeBuffer(o,0,d),e.particleLayers.length>0){let t=d[32],n=d[33],r=d[34],a=d[36],o=d[37],s=d[38],c=d[48],l=d[60];for(let u of e.particleLayers){if(!u.uniform||!u.style)continue;let e=u.style;if(d[32]=t,d[33]=n,d[34]=r,d[36]=a,d[37]=o,d[38]=s,d[48]=c,d[60]=l,e.color!==void 0){let t=I(e.color);d[32]=t[0],d[33]=t[1],d[34]=t[2]}if(e.focusColor!==void 0){let t=I(e.focusColor);d[36]=t[0],d[37]=t[1],d[38]=t[2]}e.pointsize!==void 0&&(d[48]=e.pointsize),e.highlightFocus!==void 0&&(d[60]=+!!e.highlightFocus),i.queue.writeBuffer(u.uniform,0,d)}d[32]=t,d[33]=n,d[34]=r,d[36]=a,d[37]=o,d[38]=s,d[48]=c,d[60]=l}}var Re=(function(){let e=typeof document<`u`&&document.createElement(`link`).relList;return e&&e.supports&&e.supports(`modulepreload`)?`modulepreload`:`preload`})(),ze=function(e){return`/`+e},Be={},L=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=ze(t,n),t=s(t),t in Be)return;Be[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:Re,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})};function R(e,t,n,r){if(!t)return;let i=Math.max(0,Math.min(t.x,n)),a=Math.max(0,Math.min(t.y,r)),o=Math.max(0,Math.min(t.w,n-i)),s=Math.max(0,Math.min(t.h,r-a));o!==0&&s!==0&&(e.setViewport(i,a,o,s,0,1),e.setScissorRect(i,a,o,s))}function Ve(e,t,n){if(e.canvasWidth<=0||e.canvasHeight<=0)return;let r=(t.speed??0)>0,i=e.device.createCommandEncoder(),a=0,o=0,s=0,c=e.context.getCurrentTexture(),l=c.createView(),u=e.pendingResize;u?(e.blitPipeline||L(()=>import(`./blit-BPeOoj3N.js`).then(t=>t.initBlit(e)),[]),(!e.offscreenTexture||e.offscreenTexture.width!==u.targetCw||e.offscreenTexture.height!==u.targetCh)&&(e.offscreenTexture?.destroy(),e.offscreenTexture=e.device.createTexture({size:[u.targetCw,u.targetCh],format:e.canvasFormat,usage:GPUTextureUsage.RENDER_ATTACHMENT|GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_SRC}),e.offscreenView=e.offscreenTexture.createView(),e.blitBindGroup=null)):e.offscreenTexture&&(e.offscreenTexture.destroy(),e.offscreenTexture=null,e.offscreenView=null,e.blitBindGroup=null);let d=e.offscreenTexture??c,f=e.offscreenView??l;if(r&&e.numParticles>0){let t=i.beginComputePass();t.setPipeline(e.computePipeline),t.setBindGroup(0,e.computeBindGroup);let n=Math.ceil(e.numParticles/64),r=Math.min(n,256),a=Math.ceil(n/256);t.dispatchWorkgroups(r,a),t.end()}if(e.gridComputePipeline&&e.gridBindGroup){let t=i.beginComputePass();t.setBindGroup(0,e.gridBindGroup),t.setPipeline(e.gridComputePipeline),t.dispatchWorkgroups(512),e.gridAssignPipeline&&e.shapes.size>0&&(t.setPipeline(e.gridAssignPipeline),t.dispatchWorkgroups(Math.max(1,Math.ceil(e.shapes.size/64)))),t.end()}let p=d.width,m=d.height;(!e.sdfDepthTexture||e.sdfDepthTexture.width!==p||e.sdfDepthTexture.height!==m)&&(e.sdfDepthTexture?.destroy(),e.sdfDepthTexture=e.device.createTexture({size:[p,m],format:`depth24plus`,usage:GPUTextureUsage.RENDER_ATTACHMENT}));let h=e.mesh?.isGlass===!0&&!!e.mesh?.glassPipeline,g=e.refractCount>0||h,_=!1;if(g&&(!e.bgTexture||e.bgTexture.width!==p||e.bgTexture.height!==m)){e.bgTexture?.destroy();let t=Math.floor(Math.log2(Math.max(p,m)))+1,n=Math.min(6,t);e.bgTexture=e.device.createTexture({size:[p,m],format:e.canvasFormat,mipLevelCount:n,usage:GPUTextureUsage.COPY_DST|GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.RENDER_ATTACHMENT}),e.bgSampler||=e.device.createSampler({magFilter:`linear`,minFilter:`linear`,mipmapFilter:`linear`}),e.bgMipBindGroups=null,e.bgMipDstViews=null,_=!0}if(g&&(!e.reflectionTexture||e.reflectionTexture.width!==p||e.reflectionTexture.height!==m)){e.reflectionTexture?.destroy();let t=Math.floor(Math.log2(Math.max(p,m)))+1,n=Math.min(6,t);e.reflectionTexture=e.device.createTexture({size:[p,m],format:e.canvasFormat,mipLevelCount:n,usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.RENDER_ATTACHMENT}),e.reflMipBindGroups=null,e.reflMipDstViews=null,_=!0}g&&e.bgTexture&&e.reflectionTexture&&e.sdfRefractPipeline&&(!e.refractBindGroup||_)&&(e.refractBindGroup=e.device.createBindGroup({layout:e.sdfRefractPipeline.getBindGroupLayout(1),entries:[{binding:0,resource:e.bgTexture.createView()},{binding:1,resource:e.bgSampler},{binding:2,resource:e.reflectionTexture.createView()}]}));let v=!1;h?((!e.mesh.glassBackPosTexture||e.mesh.glassBackPosTexture.width!==p||e.mesh.glassBackPosTexture.height!==m)&&(e.mesh.glassBackPosTexture?.destroy(),e.mesh.glassBackPosDepth?.destroy(),e.mesh.glassBackPosTexture=e.device.createTexture({size:[p,m],format:`rgba16float`,usage:GPUTextureUsage.RENDER_ATTACHMENT|GPUTextureUsage.TEXTURE_BINDING}),e.mesh.glassBackPosView=e.mesh.glassBackPosTexture.createView(),e.mesh.glassBackPosDepth=e.device.createTexture({size:[p,m],format:`depth24plus`,usage:GPUTextureUsage.RENDER_ATTACHMENT}),e.mesh.glassBackPosDepthView=e.mesh.glassBackPosDepth.createView(),e.mesh.glassBackPosSampler||(e.mesh.glassBackPosSampler=e.device.createSampler({magFilter:`nearest`,minFilter:`nearest`})),v=!0),e.mesh.glassPipeline&&e.bgTexture&&e.reflectionTexture&&e.mesh.glassBackPosView&&e.mesh.glassBgl2&&(!e.mesh.glassBindGroup||_||v)&&(e.mesh.glassBindGroup=e.device.createBindGroup({layout:e.mesh.glassBgl2,entries:[{binding:0,resource:e.bgTexture.createView()},{binding:1,resource:e.bgSampler},{binding:2,resource:e.mesh.glassBackPosView},{binding:3,resource:e.mesh.glassBackPosSampler},{binding:4,resource:e.reflectionTexture.createView()}]}))):e.mesh?.glassBackPosTexture&&(e.mesh.glassBackPosTexture.destroy(),e.mesh.glassBackPosDepth?.destroy(),e.mesh.glassBackPosTexture=null,e.mesh.glassBackPosView=null,e.mesh.glassBackPosDepth=null,e.mesh.glassBackPosDepthView=null,e.mesh.glassBindGroup=null);let y=!!t.stats&&e.gpuTimestampSupported;y&&!e.gpuTimestampQuerySet&&(e.gpuTimestampQuerySet=e.device.createQuerySet({type:`timestamp`,count:4}),e.gpuTimestampResolve=e.device.createBuffer({size:32,usage:GPUBufferUsage.QUERY_RESOLVE|GPUBufferUsage.COPY_SRC}),e.gpuTimestampReadback=e.device.createBuffer({size:32,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST}));let b=y&&!!e.gpuTimestampQuerySet,x=b?{querySet:e.gpuTimestampQuerySet,beginningOfPassWriteIndex:0,endOfPassWriteIndex:1}:void 0,S=b&&g?{querySet:e.gpuTimestampQuerySet,beginningOfPassWriteIndex:2,endOfPassWriteIndex:3}:void 0,C=e.sdfDepthTexture.createView(),w=i.beginRenderPass({colorAttachments:[{view:f,clearValue:{r:0,g:0,b:0,a:0},loadOp:`clear`,storeOp:`store`}],depthStencilAttachment:{view:C,depthLoadOp:`clear`,depthStoreOp:`discard`,depthClearValue:1},timestampWrites:x});R(w,n,p,m),o++,e.numParticles>0&&(w.setPipeline(e.renderPipeline),w.setBindGroup(0,e.renderBindGroup),w.draw(6,e.numParticles),a++);for(let t of e.particleLayers)t.numParticles>0&&(w.setPipeline(e.renderPipeline),w.setBindGroup(0,t.bindGroup),w.draw(6,t.numParticles),a++);if(t.showAxes&&e.axesPipeline&&(w.setPipeline(e.axesPipeline),w.setBindGroup(0,e.renderBindGroup),w.draw(6),a++),e.textPipeline&&e.texts.size>0){w.setPipeline(e.textPipeline),w.setVertexBuffer(0,e.textQuadVertexBuffer),w.setIndexBuffer(e.textQuadIndexBuffer,`uint16`);for(let t of e.texts.values())!t.bindGroup||(t.instanceCount??0)===0||(w.setBindGroup(0,t.bindGroup),w.drawIndexed(6,t.instanceCount,0,0,0),a++)}if(g&&e.bgTexture){w.end(),i.copyTextureToTexture({texture:d},{texture:e.bgTexture},[p,m,1]);let r=e.visibleTotal-e.fastCount-e.refractCount,c=(e.fastCount>0||r>0)&&!!e.cubeVertexBuffer&&!!e.cubeIndexBuffer;if(t.enableReflection&&c&&e.reflectionTexture){let t=i.beginRenderPass({colorAttachments:[{view:e.reflectionTexture.createView({baseMipLevel:0,mipLevelCount:1}),clearValue:{r:0,g:0,b:0,a:0},loadOp:`clear`,storeOp:`store`}],depthStencilAttachment:{view:C,depthLoadOp:`clear`,depthStoreOp:`discard`,depthClearValue:1}});if(R(t,n,p,m),t.setBindGroup(0,e.renderBindGroup),t.setVertexBuffer(0,e.cubeVertexBuffer),t.setIndexBuffer(e.cubeIndexBuffer,`uint16`),e.fastCount>0&&e.sdfFastPipeline&&(t.setPipeline(e.sdfFastPipeline),t.drawIndexed(36,e.fastCount,0,0,0),a++),r>0&&e.sdfPipeline&&(t.setPipeline(e.sdfPipeline),t.drawIndexed(36,r,0,0,e.fastCount+e.refractCount),a++),t.end(),o++,e.bgMipPipeline&&e.reflectionTexture.mipLevelCount>1){if(!e.reflMipBindGroups||!e.reflMipDstViews){let t=e.bgMipPipeline.getBindGroupLayout(0),n=[],r=[];for(let i=1;i<e.reflectionTexture.mipLevelCount;i++)n.push(e.device.createBindGroup({layout:t,entries:[{binding:0,resource:e.reflectionTexture.createView({baseMipLevel:i-1,mipLevelCount:1})},{binding:1,resource:e.bgSampler}]})),r.push(e.reflectionTexture.createView({baseMipLevel:i,mipLevelCount:1}));e.reflMipBindGroups=n,e.reflMipDstViews=r}for(let t=1;t<e.reflectionTexture.mipLevelCount;t++){let n=i.beginRenderPass({colorAttachments:[{view:e.reflMipDstViews[t-1],loadOp:`clear`,storeOp:`store`,clearValue:{r:0,g:0,b:0,a:0}}]});n.setPipeline(e.bgMipPipeline),n.setBindGroup(0,e.reflMipBindGroups[t-1]),n.draw(3),n.end(),a++,s++}}}let l=e.bgMipsNeeded||!!e.mesh?.glassNeedsMips||!!t.enableReflection;if(l&&e.bgMipPipeline&&e.bgTexture.mipLevelCount>1){if(!e.bgMipBindGroups||!e.bgMipDstViews){let t=e.bgMipPipeline.getBindGroupLayout(0),n=[],r=[];for(let i=1;i<e.bgTexture.mipLevelCount;i++)n.push(e.device.createBindGroup({layout:t,entries:[{binding:0,resource:e.bgTexture.createView({baseMipLevel:i-1,mipLevelCount:1})},{binding:1,resource:e.bgSampler}]})),r.push(e.bgTexture.createView({baseMipLevel:i,mipLevelCount:1}));e.bgMipBindGroups=n,e.bgMipDstViews=r}for(let t=1;t<e.bgTexture.mipLevelCount;t++){let n=i.beginRenderPass({colorAttachments:[{view:e.bgMipDstViews[t-1],loadOp:`clear`,storeOp:`store`,clearValue:{r:0,g:0,b:0,a:0}}]});n.setPipeline(e.bgMipPipeline),n.setBindGroup(0,e.bgMipBindGroups[t-1]),n.draw(3),n.end(),a++,s++}}else l&&e.bgMipPipeline;if(h&&e.mesh.glassBackPosPipeline&&e.mesh.glassBackPosView&&e.mesh.glassBackPosDepthView&&e.mesh.bindGroup0&&e.mesh.bindGroup1&&e.mesh.vertexBuffer&&e.mesh.normalBuffer&&e.mesh.colorBuffer){let t=i.beginRenderPass({colorAttachments:[{view:e.mesh.glassBackPosView,clearValue:{r:0,g:0,b:0,a:0},loadOp:`clear`,storeOp:`store`}],depthStencilAttachment:{view:e.mesh.glassBackPosDepthView,depthLoadOp:`clear`,depthStoreOp:`discard`,depthClearValue:1}});R(t,n,p,m),t.setPipeline(e.mesh.glassBackPosPipeline),t.setBindGroup(0,e.mesh.bindGroup0),t.setBindGroup(1,e.mesh.bindGroup1),t.setVertexBuffer(0,e.mesh.vertexBuffer),t.setVertexBuffer(1,e.mesh.normalBuffer),t.setVertexBuffer(2,e.mesh.colorBuffer),e.mesh.uvBuffer&&t.setVertexBuffer(3,e.mesh.uvBuffer),e.mesh.bindPosBuffer&&t.setVertexBuffer(4,e.mesh.bindPosBuffer),e.mesh.indexBuffer?(t.setIndexBuffer(e.mesh.indexBuffer,e.mesh.indexFormat??`uint16`),t.drawIndexed(e.mesh.indexCount)):t.draw(e.mesh.indexCount),t.end(),a++,o++}w=i.beginRenderPass({colorAttachments:[{view:f,loadOp:`load`,storeOp:`store`}],depthStencilAttachment:{view:C,depthLoadOp:`clear`,depthStoreOp:`store`,depthClearValue:1},timestampWrites:S}),R(w,n,p,m),o++}let T=e.fastCount,E=e.visibleTotal,D=E-T-e.refractCount,O=E>0&&e.cubeVertexBuffer&&e.cubeIndexBuffer&&(e.objectsBuffer?.size??0)>16;if(O&&T>0&&e.sdfFastPipeline&&(w.setBindGroup(0,e.renderBindGroup),w.setVertexBuffer(0,e.cubeVertexBuffer),w.setIndexBuffer(e.cubeIndexBuffer,`uint16`),w.setPipeline(e.sdfFastPipeline),w.drawIndexed(36,T,0,0,0),a++),e.mesh?.pipeline&&e.mesh.vertexBuffer&&e.mesh.normalBuffer&&e.mesh.colorBuffer&&e.mesh.bindGroup0&&e.mesh.bindGroup1){let t=h&&e.mesh.glassPipeline&&e.mesh.glassBindGroup;w.setPipeline(t?e.mesh.glassPipeline:e.mesh.pipeline),w.setBindGroup(0,e.mesh.bindGroup0),w.setBindGroup(1,e.mesh.bindGroup1),t&&w.setBindGroup(2,e.mesh.glassBindGroup),w.setVertexBuffer(0,e.mesh.vertexBuffer),w.setVertexBuffer(1,e.mesh.normalBuffer),w.setVertexBuffer(2,e.mesh.colorBuffer),e.mesh.uvBuffer&&w.setVertexBuffer(3,e.mesh.uvBuffer),e.mesh.bindPosBuffer&&w.setVertexBuffer(4,e.mesh.bindPosBuffer),e.mesh.indexBuffer?(w.setIndexBuffer(e.mesh.indexBuffer,e.mesh.indexFormat??`uint16`),w.drawIndexed(e.mesh.indexCount)):w.draw(e.mesh.indexCount),a++}if(O&&T>0&&e.hasFastEffect&&e.sdfFastEffectPipeline&&(w.setBindGroup(0,e.renderBindGroup),w.setVertexBuffer(0,e.cubeVertexBuffer),w.setIndexBuffer(e.cubeIndexBuffer,`uint16`),w.setPipeline(e.sdfFastEffectPipeline),w.drawIndexed(36,T,0,0,0),a++),O&&e.refractCount>0&&e.sdfRefractPipeline&&e.refractBindGroup&&(w.setBindGroup(0,e.renderBindGroup),w.setBindGroup(1,e.refractBindGroup),w.setVertexBuffer(0,e.cubeVertexBuffer),w.setIndexBuffer(e.cubeIndexBuffer,`uint16`),w.setPipeline(e.sdfRefractPipeline),w.drawIndexed(36,e.refractCount,0,0,T),a++),O&&D>0&&e.sdfPipeline&&(w.setBindGroup(0,e.renderBindGroup),w.setVertexBuffer(0,e.cubeVertexBuffer),w.setIndexBuffer(e.cubeIndexBuffer,`uint16`),w.setPipeline(e.sdfPipeline),w.drawIndexed(36,D,0,0,T+e.refractCount),a++),w.end(),e.offscreenView&&e.blitPipeline&&e.blitSampler){e.blitBindGroup||=e.device.createBindGroup({layout:e.blitPipeline.getBindGroupLayout(0),entries:[{binding:0,resource:e.offscreenView},{binding:1,resource:e.blitSampler}]});let t=i.beginRenderPass({colorAttachments:[{view:l,clearValue:{r:0,g:0,b:0,a:0},loadOp:`clear`,storeOp:`store`}]});t.setPipeline(e.blitPipeline),t.setBindGroup(0,e.blitBindGroup),t.draw(3),t.end(),a++,o++}let k=g?4:2,A=k*8;if(b&&e.gpuTimestampQuerySet&&e.gpuTimestampResolve&&e.gpuTimestampReadback&&!e.gpuTimestampReading&&(i.resolveQuerySet(e.gpuTimestampQuerySet,0,k,e.gpuTimestampResolve,0),i.copyBufferToBuffer(e.gpuTimestampResolve,0,e.gpuTimestampReadback,0,A)),e.device.queue.submit([i.finish()]),e.stats.drawCalls=a,e.stats.passes=o,e.stats.bgMips=s,b&&e.gpuTimestampReadback&&!e.gpuTimestampReading){e.gpuTimestampReading=!0;let t=g;e.gpuTimestampReadback.mapAsync(GPUMapMode.READ).then(()=>{let n=new BigInt64Array(e.gpuTimestampReadback.getMappedRange()),r=t?Number(n[1]-n[0])+Number(n[3]-n[2]):Number(n[1]-n[0]);e.gpuTimestampReadback.unmap(),e.stats.gpuMs=r/1e6,e.gpuTimestampReading=!1}).catch(()=>{e.gpuTimestampReading=!1})}}function He({canvas:e,gpu:t,gpuRef:n,cameraRef:r,sceneRef:i,camPosRef:a,shapesRef:o,setGpuError:s}){let c=!1;return(async()=>{if(!navigator.gpu){s(`WebGPU not supported in this browser.`);return}let l=window;if(!l.__FABRIC_SHARED__){let e=await navigator.gpu.requestAdapter({powerPreference:`high-performance`});if(!e){s(`No WebGPU adapter found.`);return}let t=e.features.has(`timestamp-query`),n=await e.requestDevice({requiredFeatures:t?[`timestamp-query`]:[],requiredLimits:{maxStorageBufferBindingSize:e.limits.maxStorageBufferBindingSize,maxBufferSize:e.limits.maxBufferSize,maxComputeWorkgroupsPerDimension:e.limits.maxComputeWorkgroupsPerDimension}}),r=e.info??{};if(!r.vendor&&!r.architecture&&!r.device&&!r.description&&typeof e.requestAdapterInfo==`function`)try{r=await e.requestAdapterInfo()}catch{r={}}l.__FABRIC_SHARED__={adapter:e,device:n,adapterInfo:{vendor:r.vendor??``,architecture:r.architecture??``,device:r.device??``,description:r.description??``}}}let{device:u,adapterInfo:d}=l.__FABRIC_SHARED__,f=u.features.has(`timestamp-query`);if(c)return;let p=Math.min(window.devicePixelRatio,2),m=e.clientWidth||window.innerWidth||1,h=e.clientHeight||window.innerHeight||1;e.width=Math.round(m*p),e.height=Math.round(h*p);let g=e.getContext(`webgpu`),_=navigator.gpu.getPreferredCanvasFormat();g.configure({device:u,format:_,alphaMode:`premultiplied`,usage:GPUTextureUsage.RENDER_ATTACHMENT|GPUTextureUsage.COPY_SRC});let v={device:u,context:g,canvasFormat:_,originalPositionsBuffer:null,currentPositionsBuffer:null,plyColorsBuffer:null,simUniformBuffer:u.createBuffer({size:32,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),renderUniformBuffer:u.createBuffer({size:512,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),objectsBuffer:u.createBuffer({size:1048576,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),gridBuffer:null,cubeVertexBuffer:null,cubeIndexBuffer:null,computePipeline:null,gridComputePipeline:null,renderPipeline:null,axesPipeline:null,sdfPipeline:null,sdfFastPipeline:null,sdfFastEffectPipeline:null,sdfRefractPipeline:null,refractBindGroup:null,hasFastEffect:!1,fastEffectConfig:null,sdfDepthTexture:null,bgTexture:null,bgSampler:null,reflectionTexture:null,reflMipBindGroups:null,reflMipDstViews:null,bgMipPipeline:null,bgMipBindGroups:null,bgMipDstViews:null,bgMipsNeeded:!1,offscreenTexture:null,offscreenView:null,blitPipeline:null,blitBindGroup:null,blitSampler:null,pendingResize:null,fastCount:0,refractCount:0,computeBindGroup:null,gridBindGroup:null,renderBindGroup:null,views:new Map,hiddenGroups:new Set,visibleTotal:0,texts:new Map,fonts:new Map,cameraRef:r,numParticles:0,particleLayers:[],canvasWidth:m,canvasHeight:h,pixelRatio:p,gridScaleBaseHeight:h,internalTime:0,lastTimestamp:0,lastRenderTime:0,renderDirtyFrames:2,camPos:{x:0,y:0,z:8},camAspect:m/h,mvpMatrix:N(),modelMatrix:N(),modelViewMatrix:N(),projMatrix:N(),viewMatrix:N(),simUniformData:new Float32Array(8),renderUniformData:new Float32Array(128),springs:{rotation:new j(0),amplitude:new j(0)},pointer:{x:0,y:0},trackMouse:!1,pointerFromOrientation:!1,shapes:o.current,stats:{fps:60,latency:0,gpuMs:0,drawCalls:0,passes:0,bgMips:0,frameTimes:new Float32Array(60),frameTimeIdx:0},adapterInfo:d,gpuTimestampSupported:f,gpuTimestampQuerySet:null,gpuTimestampResolve:null,gpuTimestampReadback:null,gpuTimestampReading:!1,rafId:null,isVisible:!1,sceneRef:i};t.set(null),n.current=v;for(let e of Object.values(v.springs))e.on(`change`,()=>{v.renderDirtyFrames=Math.max(v.renderDirtyFrames,2)});Me(v),Fe(v,i.current,i.current.geometryUrl),v.numParticles=0,t.set(v),L(()=>import(`./blit-BPeOoj3N.js`).then(e=>e.initBlit(v)),[]).catch(()=>{});let y=new ResizeObserver(t=>{for(let n of t){let t=n.contentRect.width,r=n.contentRect.height;if(t<=0||r<=0)continue;let i=Math.round(t*v.pixelRatio),a=Math.round(r*v.pixelRatio);e.width===i&&e.height===a&&!v.pendingResize||(v.canvasWidth=t,v.canvasHeight=r,v.camAspect=t/r,v.pendingResize={targetCw:i,targetCh:a,ew:t,eh:r,framesIdle:0},v.renderDirtyFrames=Math.max(v.renderDirtyFrames,4))}});y.observe(e);let b=()=>{};window.addEventListener(`orientationchange`,b);let x=new IntersectionObserver(([e])=>{v.isVisible=e.isIntersecting,v.isVisible&&(v.renderDirtyFrames=60)});x.observe(e);function S(t){if(v.rafId=requestAnimationFrame(S),!v.isVisible)return;let n=1e3/(i.current.fps??60)-1;if(v.lastRenderTime===0){v.lastRenderTime=t;return}if(t-v.lastRenderTime<n)return;let o=Math.min((t-v.lastRenderTime)/1e3,.1);v.lastRenderTime=t,v.stats.fps=1/o;let s=v.pendingResize;s&&(s.framesIdle++,s.framesIdle>=6&&(e.width=s.targetCw,e.height=s.targetCh,v.pendingResize=null,v.renderDirtyFrames=Math.max(v.renderDirtyFrames,4)));let c=(i.current.speed??0)>0;if(!c&&v.renderDirtyFrames<=0)return;v.renderDirtyFrames>0&&v.renderDirtyFrames--,v.camPos.x=a.current.x,v.camPos.y=a.current.y,v.camPos.z=a.current.z,v.camAspect=v.canvasWidth/v.canvasHeight,v.internalTime+=o*(i.current.speed??0);let l=performance.now();if(Le(v,r.current,i.current,o),(v.renderDirtyFrames>0||c)&&v._sdfUpdate&&v._sdfUpdate(),(v.renderDirtyFrames>0||c)&&v._textUpdate&&v._textUpdate(),v.views.size===0)Ve(v,i.current);else{let e=v.context.canvas.getBoundingClientRect(),t=Math.round(v.canvasWidth*v.pixelRatio),n=Math.round(v.canvasHeight*v.pixelRatio),a=[...v.views.values()].sort((e,t)=>e.index-t.index);for(let s of a){if(!s.visible||s.offscreen)continue;let a=s.rect.left-e.left,c=s.rect.top-e.top,l=Math.round(a*v.pixelRatio),u=Math.round(c*v.pixelRatio),d=Math.round(s.rect.width*v.pixelRatio),f=Math.round(s.rect.height*v.pixelRatio);if(l+d<=0||u+f<=0||l>=t||u>=n)continue;let p=Math.max(0,l),m=Math.max(0,u),h=Math.min(t-p,d-(p-l)),g=Math.min(n-m,f-(m-u));if(h<=0||g<=0)continue;v.camAspect=d/f;let _=r.current,y=s.camera.fov!=null||s.camera.zoom!=null?{..._,...s.camera.fov==null?null:{fov:s.camera.fov},...s.camera.zoom==null?null:{zoom:s.camera.zoom}}:_,b=null;if(s.camera.position){b=v.camPos;let[e,t,n]=s.camera.position;v.camPos={x:e,y:t,z:n}}Le(v,y,i.current,o),Ve(v,i.current,{x:p,y:m,w:h,h:g}),b&&(v.camPos=b)}}v.stats.latency=performance.now()-l,v.stats.frameTimes[v.stats.frameTimeIdx]=v.stats.latency,v.stats.frameTimeIdx=(v.stats.frameTimeIdx+1)%v.stats.frameTimes.length}v.rafId=requestAnimationFrame(S),v._cleanup=()=>{y.disconnect(),x.disconnect(),window.removeEventListener(`orientationchange`,b),v.rafId!==null&&cancelAnimationFrame(v.rafId)}})(),()=>{c=!0,t.set(null);let e=n.current;if(e){e._cleanup?.();try{e.simUniformBuffer?.destroy(),e.renderUniformBuffer?.destroy(),e.objectsBuffer?.destroy(),e.gridBuffer?.destroy(),e.cubeVertexBuffer?.destroy(),e.cubeIndexBuffer?.destroy(),e.sdfDepthTexture?.destroy(),e.reflectionTexture?.destroy(),e.gpuTimestampQuerySet?.destroy(),e.gpuTimestampResolve?.destroy(),e.gpuTimestampReadback?.destroy(),e.mesh&&(e.mesh.vertexBuffer?.destroy(),e.mesh.normalBuffer?.destroy(),e.mesh.colorBuffer?.destroy(),e.mesh.indexBuffer?.destroy(),e.mesh.modelBuffer?.destroy(),e.mesh.uvBuffer?.destroy(),e.mesh.texture?.destroy()),e.originalPositionsBuffer?.destroy(),e.currentPositionsBuffer?.destroy(),e.plyColorsBuffer?.destroy();for(let t of e.particleLayers)t.current?.destroy()}catch{}}n.current=null}}function z(e){return Math.sqrt(e.x*e.x+e.y*e.y+e.z*e.z)}function Ue(e,t){return{x:e.x-t.x,y:e.y-t.y,z:e.z-t.z}}function We(e,t){let n={...e},r=Math.cos(t.z),i=Math.sin(t.z);n={x:r*n.x-i*n.y,y:i*n.x+r*n.y,z:n.z};let a=Math.cos(t.y),o=Math.sin(t.y);n={x:a*n.x+o*n.z,y:n.y,z:-o*n.x+a*n.z};let s=Math.cos(t.x),c=Math.sin(t.x);return n={x:n.x,y:s*n.y-c*n.z,z:c*n.y+s*n.z},n}function B(e,t){return z(e)-t}function Ge(e,t){let n={x:Math.abs(e.x)-t.x,y:Math.abs(e.y)-t.y,z:Math.abs(e.z)-t.z};return z({x:Math.max(n.x,0),y:Math.max(n.y,0),z:Math.max(n.z,0)})+Math.min(Math.max(n.x,Math.max(n.y,n.z)),0)}function Ke(e,t,n){let r={x:Math.sqrt(e.x*e.x+e.z*e.z)-t,y:e.y};return Math.sqrt(r.x*r.x+r.y*r.y)-n}function qe(e,t,n){let r={...e};return r.y-=Math.max(-t,Math.min(t,e.y)),z(r)-n}function Je(e,t,n){let r=Math.min(n,Math.min(t.x,t.y)),i=Math.abs(e.x)-t.x+r,a=Math.abs(e.y)-t.y+r,o=Math.sqrt(Math.max(i,0)**2+Math.max(a,0)**2)+Math.min(Math.max(i,a),0)-r,s=Math.abs(e.z)-t.z;return Math.min(Math.max(o,s),0)+Math.sqrt(Math.max(o,0)**2+Math.max(s,0)**2)}function Ye(e,t,n){let r=e.y-n,i=t,a=-2*n,o=Math.sqrt(e.x*e.x+e.z*e.z),s=r,c=i*i+a*a,l=Math.max(0,Math.min(1,(o*i+s*a)/c)),u=o-i*l,d=s-a*l,f=o-i*Math.max(0,Math.min(1,o/i)),p=s-a*1,m=Math.sign(a),h=Math.min(u*u+d*d,f*f+p*p),g=Math.max(m*(o*a-s*i),m*(s-a));return Math.sqrt(h)*Math.sign(g)}function Xe(e,t,n){let r=Math.sqrt(e.x*e.x+e.z*e.z)-t,i=Math.abs(e.y)-n;return Math.min(Math.max(r,i),0)+Math.sqrt(Math.max(r,0)**2+Math.max(i,0)**2)}function Ze(e,t,n,r){let i=Math.min(n,Math.min(t,r)),a=Math.sqrt(e.x*e.x+e.z*e.z)-t+i,o=Math.abs(e.y)-r+i;return Math.min(Math.max(a,o),0)+Math.sqrt(Math.max(a,0)**2+Math.max(o,0)**2)-i}function Qe(e,t,n,r){let i=Math.sqrt(e.x*e.x+e.z*e.z),a=e.y,o=r,s=t,c=r-n,l=2*t,u=i-Math.min(i,a<0?n:r),d=Math.abs(a)-t,f=(o-i)*c+(s-a)*l,p=c*c+l*l,m=Math.max(0,Math.min(1,f/p)),h=i-o+c*m,g=a-s+l*m;return(h<0&&d<0?-1:1)*Math.sqrt(Math.min(u*u+d*d,h*h+g*g))}function $e(e,t,n){let r=Math.sqrt(t*t+n*n);return Math.sqrt(e.x*e.x+e.y*e.y+e.z*e.z)-r}function et(e,t){return(Math.abs(e.x)+Math.abs(e.y)+Math.abs(e.z)-t)*.57735027}function tt(e,t,n){return Xe(e,t,n)}function nt(e,t){let n=Math.sqrt((e.x/t.x)**2+(e.y/t.y)**2+(e.z/t.z)**2),r=Math.sqrt((e.x/(t.x*t.x))**2+(e.y/(t.y*t.y))**2+(e.z/(t.z*t.z))**2);return n*(n-1)/r}function rt(e,t,n){let r=new Float32Array(16),i=new Float32Array(16);if(!ke(r,e.projMatrix)||!ke(i,e.viewMatrix))return{origin:e.camPos,direction:{x:0,y:0,z:-1}};function a(e){let t=[0,0,0,0];for(let n=0;n<4;n++){let i=0;for(let t=0;t<4;t++)i+=r[t*4+n]*e[t];t[n]=i}let n=[t[0]/t[3],t[1]/t[3],t[2]/t[3],1],a=[0,0,0,0];for(let e=0;e<4;e++){let t=0;for(let r=0;r<4;r++)t+=i[r*4+e]*n[r];a[e]=t}return{x:a[0],y:a[1],z:a[2]}}let o=a([t,n,0,1]),s=Ue(a([t,n,1,1]),o),c=z(s);return{origin:o,direction:{x:s.x/c,y:s.y/c,z:s.z/c}}}function V(e,t=0){return e==null?t:typeof e==`number`?e:e.get?.()??e.value??t}function it(e){return{x:V(e.x),y:V(e.y),z:V(e.z)}}function at(e,t){let n=null,r=1e4;for(let[i,a]of t){let t=0,o=it(a.position),s=it(a.size),c=it(a.rotation),l=V(a.roundness,0),u=V(a.modifier?.revolve,0),d={x:-c.x,y:-c.y,z:-c.z};for(let c=0;c<32;c++){let c=We(Ue({x:e.origin.x+e.direction.x*t,y:e.origin.y+e.direction.y*t,z:e.origin.z+e.direction.z*t},o),d),f=1e4;switch(a.type){case 0:f=Ge(c,s);break;case 1:f=qe(c,s.y,s.x);break;case 2:f=B(c,s.x);break;case 3:f=Ke(c,s.x,s.y);break;case 4:f=Je(c,s,l);break;case 5:f=Ye(c,s.x,s.y);break;case 6:f=Xe(c,s.x,s.y);break;case 7:f=Ze(c,s.x,l,s.y);break;case 8:f=Qe(c,s.y,s.x,s.z);break;case 9:f=$e(c,s.x,s.y);break;case 10:f=et(c,s.x);break;case 11:f=tt(c,s.x,s.y);break;case 12:f=nt(c,s);break;case 13:f=B(c,Math.max(s.x,s.y));break;case 14:f=B(c,Math.max(s.x,s.z)+s.y);break;case 15:f=Ge(c,s);break;case 16:f=B(c,Math.max(s.x,s.y)+l);break;case 17:f=B(c,s.x);break;case 18:f=B(c,s.x+s.z);break;case 19:f=B(c,s.x);break;case 20:f=B(c,s.y);break;case 21:f=B(c,s.x+s.y+s.z);break;case 30:f=B(c,s.x+u);break;case 31:f=B(c,Math.max(s.x,s.y)+u);break;case 32:f=B(c,Math.max(s.x,s.y)+u)}if(f<.05){t<r&&(r=t,n=i);break}if(t+=f,t>50)break}}return n}function ot({canvas:e,gpuRef:t}){let n=null,r,i=e.getBoundingClientRect(),a=()=>{i=e.getBoundingClientRect()};window.addEventListener(`resize`,a,{passive:!0}),window.addEventListener(`scroll`,a,{passive:!0});let o=e=>{let n=t.current;n&&(n.pointer.x=(e.clientX-i.left)/i.width*2-1,n.pointer.y=-((e.clientY-i.top)/i.height*2-1),n.renderDirtyFrames=Math.max(n.renderDirtyFrames,2))},s=e=>{let n=t.current;if(!n||!n.isVisible)return;let r=at(rt(n,n.pointer.x,n.pointer.y),n.shapes);if(r){let t=n.shapes.get(r);t?.onClick&&t.onClick(t,e)}},c=()=>{r=requestAnimationFrame(c);let i=t.current;if(!i||!i.isVisible||i.shapes.size===0)return;if(i.pointerFromOrientation){if(n!==null){let t=i.shapes.get(n);t?.onPointerOut&&t.onPointerOut(t),n=null,e.style.cursor=`default`}return}let a=!1;for(let e of i.shapes.values())if(e.onClick||e.onPointerOver||e.onPointerOut){a=!0;break}if(!a){n!==null&&(e.style.cursor=`default`,n=null);return}let o=at(rt(i,i.pointer.x,i.pointer.y),i.shapes);if(o!==n){if(e.style.cursor=o?`pointer`:`default`,n){let e=i.shapes.get(n);e?.onPointerOut&&e.onPointerOut(e)}if(o){let e=i.shapes.get(o);e?.onPointerOver&&e.onPointerOver(e)}n=o}};return window.addEventListener(`mousemove`,o),e.addEventListener(`click`,s),c(),()=>{cancelAnimationFrame(r),window.removeEventListener(`mousemove`,o),e.removeEventListener(`click`,s),window.removeEventListener(`resize`,a),window.removeEventListener(`scroll`,a)}}function st(e){let t=M();if(t.gpuRef.current)return()=>{};Se(e);let n=He({canvas:e,gpu:t.gpu,gpuRef:t.gpuRef,cameraRef:t.cameraRef,sceneRef:t.sceneRef,camPosRef:t.camPosRef,shapesRef:t.shapesRef,setGpuError:Ce}),r=ot({canvas:e,gpuRef:t.gpuRef}),i=e=>{!e.isTrusted||e.target?.matches?.(`input, textarea, select, [contenteditable]`)||e.key?.toLowerCase()===`h`&&(t.sceneRef.current.debugMode=!t.sceneRef.current.debugMode,t.gpuRef.current&&(t.gpuRef.current.renderDirtyFrames=2))};return window.addEventListener(`keydown`,i),()=>{n(),r(),window.removeEventListener(`keydown`,i),Se(void 0)}}var H=`unknown`,ct=new Set,lt=!1;function ut(e){if(H!==e){H=e;for(let t of ct)t(e)}}function dt(){return typeof window<`u`&&window.DeviceOrientationEvent!==void 0&&typeof window.DeviceOrientationEvent.requestPermission==`function`}function ft(){if(lt||typeof window>`u`)return;if(lt=!0,!dt()){ut(`granted`);return}let e=t=>{t.beta!=null&&t.gamma!=null&&(window.removeEventListener(`deviceorientation`,e),H===`unknown`&&ut(`granted`))};window.addEventListener(`deviceorientation`,e)}function pt(){return ft(),H===`granted`}var mt={x:0,y:0},U={x:0,y:0},W={x:0,y:0},G=!0,ht=!1,gt=null,_t=0,vt=.001,yt=2;function bt(e,t,n,r){return e+(t-e)*(1-Math.exp(-n*r))}function xt(e){let t=Math.min((e-_t)/1e3,.1);_t=e;let n=X.range?.x??kt,r=X.range?.y??At,i=X.easing??jt,a,o,s;if(G){let e=U.x,t=-U.y;a=Math.sin(e)*n,o=t*r,s=i}else a=0,o=0,s=yt;W.x=bt(W.x,a,s,t),W.y=bt(W.y,o,s,t),gt=Math.abs(W.x-a)<vt&&Math.abs(W.y-o)<vt?null:requestAnimationFrame(xt)}function K(){gt===null&&(_t=performance.now(),gt=requestAnimationFrame(xt))}var q=null,J=!1,Y=!1;function St(e){Y!==e&&(Y=e,e||(G=!1,K()))}function Ct(){if(ht||typeof window>`u`)return;ht=!0;let e=()=>[window.innerWidth||1,window.innerHeight||1];window.addEventListener(`mousemove`,t=>{if(!Y)return;if(!J){if(!q){q={x:t.clientX,y:t.clientY};return}let e=t.clientX-q.x,n=t.clientY-q.y;if(e*e+n*n<36)return;J=!0}let[n,r]=e();U.x=t.clientX/n*2-1,U.y=t.clientY/r*2-1,G=!0,K()},{passive:!0}),window.addEventListener(`mouseout`,e=>{Y&&J&&(e.relatedTarget??(G=!1,K()))},{passive:!0}),window.addEventListener(`mouseover`,t=>{if(!Y)return;let n=t;if(n.relatedTarget==null){J=!0;let[t,r]=e();U.x=n.clientX/t*2-1,U.y=n.clientY/r*2-1,G=!0,K()}},{passive:!0})}var wt=!1,Tt=!1;function Et(e){Tt!==e&&(Tt=e,e||(G=!1,K()))}function Dt(){wt||typeof window>`u`||(wt=!0,pt(),window.addEventListener(`deviceorientation`,e=>{if(!Tt||e.beta==null||e.gamma==null||Math.abs(e.beta)<.5&&Math.abs(e.gamma)<.5)return;let t=e.gamma/45,n=(e.beta-15)/15;U.x=Math.max(-1,Math.min(1,t)),U.y=Math.max(-1,Math.min(1,-n)),G=!0,K()},{passive:!0}))}function Ot(e){(e.x!==mt.x||e.y!==mt.y)&&performance.now(),mt=e}var kt=2,At=1,jt=5;180/Math.PI;function Mt(){return Ct(),Dt(),{ndc:{x:U.x,y:U.y},cam:{x:W.x,y:W.y},engaged:J}}var X={rect:null,perspectivePx:1e3},Nt=new Set;function Pt(e){X=e;for(let t of Nt)t(e)}var Z=180/Math.PI;function Ft(e,t,{strength:r=1}={}){we(e,t);let i=M(),a=Mt();if(i.camPosRef.current.x=a.cam.x,i.camPosRef.current.y=a.cam.y,i.camPosRef.current.z=i.cameraRef.current.cameraZ,i.initialPointerRef.current={x:a.ndc.x,y:-a.ndc.y,engaged:a.engaged},a.engaged){let e=Math.max(i.camPosRef.current.z,.001);Ot({x:Math.atan2(-i.camPosRef.current.y,e)*Z*r,y:Math.atan2(-i.camPosRef.current.x,e)*Z*r})}return n(()=>{let e=i.canvas();if(!e)return;let t=st(e);o(t)}),n(()=>{let e=0,t=!1,n=!1,a=0,s=0,c=()=>{let e=i.gpuRef.current;if(!e)return;let r=e.context?.canvas;if(!r)return;let o=r.getBoundingClientRect();if(o.width<=0||o.height<=0||Math.max(0,Math.min(o.right,window.innerWidth)-Math.max(0,o.left))*Math.max(0,Math.min(o.bottom,window.innerHeight)-Math.max(0,o.top))/(o.width*o.height)<.9)return;let c=Math.round(o.width),l=Math.round(o.height);if(t&&c===a&&l===s){n=!1;return}let u=i.cameraRef?.current,d=u?.fov??60;Pt({rect:o,perspectivePx:o.height/(2*Math.tan(d*Math.PI/360)),range:u?.range,cameraZ:u?.cameraZ,easing:u?.easing}),t=!0,n=!1,a=c,s=l},l=()=>{n=!0,c()};window.addEventListener(`resize`,l);let u=()=>{let a=i.gpuRef.current;if(a){if(a.trackMouse){let e=i.camPosRef.current,t=Math.max(e.z,.001);Ot({x:Math.atan2(-e.y,t)*Z*r,y:Math.atan2(-e.x,t)*Z*r})}(!t||n)&&c()}e=requestAnimationFrame(u)};e=requestAnimationFrame(u),o(()=>{cancelAnimationFrame(e),window.removeEventListener(`resize`,l)})}),i}var It=e=>(typeof e==`function`?e():e)??null,Q=(e,t,n,r)=>e+(t-e)*(1-Math.exp(-n*r));function Lt(e){let{mount:t,onUpdate:r,onPointerUpdate:i,usedevice:a=!1,mode:s=0,camPosRef:c,initialZ:l=8,zDolly:u=10,enabled:d=!0,followMouse:f=!0,easing:p=5,range:m={x:5,y:3},initialPointer:h=null}=e,g={x:0,y:0},_=!1,v=()=>{};return n(()=>{let e=It(t);if(!e)return;let n=/Android|webOS|iPhone|iPad|IEMobile/i.test(navigator.userAgent),s=a&&n,c=null,l=!1,u=e=>{if(l)return!0;if(!c)return c={x:e.clientX,y:e.clientY},!1;let t=e.clientX-c.x,n=e.clientY-c.y;return t*t+n*n<36?!1:(l=!0,!0)};h&&h.engaged&&(g.x=h.x,g.y=h.y,_=!0,l=!0,i?.(g,_,`mouse`));let d=e=>{if(e.beta===null||e.gamma===null)return;_=!0,r?.();let t=e.gamma/45,n=(e.beta-15)/15;g.x=Math.max(-1,Math.min(1,t)),g.y=Math.max(-1,Math.min(1,n)),i?.(g,_,`orientation`),v()};s&&(pt(),window.addEventListener(`deviceorientation`,d));let f=e.getBoundingClientRect(),p=()=>{f=e.getBoundingClientRect()};window.addEventListener(`resize`,p,{passive:!0}),window.addEventListener(`scroll`,p,{passive:!0});let m=e=>{let t=window.innerWidth,n=window.innerHeight,r=e.clientX>=f.left&&e.clientX<=f.right&&e.clientY>=f.top&&e.clientY<=f.bottom,i,a;r?(i=(e.clientX-f.left)/f.width*2-1,a=-((e.clientY-f.top)/f.height)*2+1):(i=e.clientX/t*2-1,a=-(e.clientY/n*2-1)),g.x=Math.max(-1,Math.min(1,i)),g.y=Math.max(-1,Math.min(1,a))},y=e=>{s||u(e)&&(_=!0,m(e),i?.(g,_,`mouse`),v())},b=e=>{s||l&&(e.relatedTarget||(_=!1,i?.(g,_,`mouse`),v()))},x=e=>{s||e.relatedTarget||(l=!0,_=!0,r?.(),v())},S=()=>{s||(l=!0,_=!0,r?.(),v())},C=()=>{s||l&&(_=!1,i?.(g,_,`touch`),v())};window.addEventListener(`mousemove`,y),window.addEventListener(`mouseout`,b),window.addEventListener(`mouseover`,x),window.addEventListener(`touchstart`,S),window.addEventListener(`touchend`,C),o(()=>{window.removeEventListener(`mousemove`,y),window.removeEventListener(`mouseout`,b),window.removeEventListener(`mouseover`,x),window.removeEventListener(`touchstart`,S),window.removeEventListener(`touchend`,C),window.removeEventListener(`deviceorientation`,d),window.removeEventListener(`resize`,p),window.removeEventListener(`scroll`,p)})}),n(()=>{if(!c)return;let e=performance.now(),t=null,n=.001,r=(e,t)=>typeof e==`function`?e():e??t,i=(e,t)=>typeof e==`function`?e():e??t,a=typeof f==`function`||typeof d==`function`,h=o=>{let v=Math.min((o-e)/1e3,.1);e=o;let y=_&&r(f,!0)&&r(d,!0);if(s===1&&y)c.current.x=Q(c.current.x,Math.sin(-g.x)*5,10,v),c.current.y=Q(c.current.y,g.y*3.5,10,v),c.current.z=Q(c.current.z,l+Math.cos(g.x)*u,10,v),t=requestAnimationFrame(h);else if(s===0&&y){let e=i(p,5);c.current.x=Q(c.current.x,Math.sin(g.x)*m.x,e,v),c.current.y=Q(c.current.y,g.y*m.y,e,v),c.current.z=Q(c.current.z,l,e,v),t=requestAnimationFrame(h)}else c.current.x=Q(c.current.x,0,2,v),c.current.y=Q(c.current.y,0,2,v),c.current.z=Q(c.current.z,l,2,v),t=Math.abs(c.current.x)<n&&Math.abs(c.current.y)<n&&Math.abs(c.current.z-l)<n&&!a?null:requestAnimationFrame(h)};v=()=>{t===null&&(e=performance.now(),t=requestAnimationFrame(h))},t=requestAnimationFrame(h),o(()=>{t!==null&&cancelAnimationFrame(t),v=()=>{}})}),null}var Rt=100;function zt({fov:t=60,zoom:n=1,cameraZ:r=8,trackMouse:i=!0,trackDevice:a=!0,cameraMode:o=0,rigMode:s=0,easing:c=5,range:l={x:5,y:3},zDolly:u=10,warpStrength:d=3,warpRadius:f=4,pointerZ:p=0,pointerFalloff:m=0}){let h=M(),{cameraRef:g,camPosRef:_,canvas:v}=h,y=(e,t,n)=>{let r=h.gpuRef.current;r&&(r.pointer=e,r.trackMouse=t,r.pointerFromOrientation=n===`orientation`,r.renderDirtyFrames=Math.max(r.renderDirtyFrames,Rt))},b=g.current,x=(e,t)=>{typeof e==`function`&&typeof e.subscribe==`function`?e.subscribe(e=>{b[t]=e;let n=h.gpuRef.current;n&&(n.renderDirtyFrames=Math.max(n.renderDirtyFrames,4))}):e!==void 0&&(b[t]=e)};x(t,`fov`),x(n,`zoom`),x(r,`cameraZ`),x(o,`cameraMode`),x(s,`rigMode`),x(d,`warpStrength`),x(f,`warpRadius`),x(p,`pointerZ`),x(m,`pointerFalloff`),x(c,`easing`),x(l,`range`),x(u,`zDolly`),x(i,`trackMouse`),x(a,`trackDevice`);let S=e=>typeof e==`function`?e():e,C=S(a),w=S(o),T=S(r),E=S(l),D=S(u),O=/Android|webOS|iPhone|iPad|IEMobile/i.test(navigator.userAgent),k=()=>O?!!S(a):!!S(i),A=()=>S(s)===0,ee=()=>S(c),j=S(i);return Et(!!C),St(!!j),typeof a==`function`&&typeof a.subscribe==`function`&&a.subscribe(e=>Et(!!e)),typeof i==`function`&&typeof i.subscribe==`function`&&i.subscribe(e=>St(!!e)),e(Lt,{mount:v,mode:w,easing:ee,range:E,camPosRef:_,initialZ:T,zDolly:D,followMouse:k,enabled:A,usedevice:C,onPointerUpdate:y,initialPointer:h.initialPointerRef.current})}function Bt(t){let r=M(),a=i(null),{translateX:s=0,translateY:c=0,translateZ:l=0,rotationX:u=0,rotationY:d=0,rotationZ:f=0,showAxes:p=!1,fps:m=60,maxSteps:h=100,sdfEpsilon:g=1e-4,lodScaling:_=0,edgeSoftness:v=1,stepRelaxation:y=1,stats:b=!1,debugMode:x=!1,autoCull:S=!1,enableReflection:C=!1}=t,w=r.sceneRef.current,T=(e,t)=>{typeof e==`function`&&typeof e.subscribe==`function`?e.subscribe(e=>{w[t]=e;let n=r.gpuRef.current;n&&(n.renderDirtyFrames=Math.max(n.renderDirtyFrames,4))}):e!==void 0&&(w[t]=e)};T(s,`translateX`),T(c,`translateY`),T(l,`translateZ`),T(u,`rotationX`),T(d,`rotationY`),T(f,`rotationZ`),T(p,`showAxes`),T(m,`fps`),T(h,`maxSteps`),T(g,`sdfEpsilon`),T(_,`lodScaling`),T(v,`edgeSoftness`),T(y,`stepRelaxation`),T(b,`stats`),T(x,`debugMode`),T(S,`autoCull`),T(C,`enableReflection`);let E=()=>!!(typeof b==`function`?b():b);return n(()=>{let e=e=>{let t=r.gpuRef.current;t&&(t.pointer={x:e.clientX,y:e.clientY},t.trackMouse||(t.trackMouse=!0,t.renderDirtyFrames=300))};window.addEventListener(`pointermove`,e),o(()=>window.removeEventListener(`pointermove`,e))}),e(`span`,{style:()=>({display:E()?`contents`:`none`}),children:()=>{let t=a();return t?e(t,{gpuRef:r.gpuRef}):null}})}var Vt=0,Ht=()=>`view-${++Vt}`,Ut=e=>typeof e==`object`&&!!e&&typeof e.canvas==`function`,Wt=e=>typeof e==`function`?e()??null:Ut(e)?e.canvas()??null:e.current??null;function Gt({track:e,camera:t,visible:r=!0,index:i=0}){let a=Ht(),s=M();return n(()=>{let n=s.gpu(),c=Wt(e);if(!n||!c)return;let l={id:a,track:c,camera:t??{},visible:r,index:i,rect:c.getBoundingClientRect(),offscreen:!1};n.views.set(a,l);let u=()=>{l.rect=c.getBoundingClientRect(),n.renderDirtyFrames=Math.max(n.renderDirtyFrames,2)},d=new ResizeObserver(u);d.observe(c),window.addEventListener(`scroll`,u,{passive:!0,capture:!0}),window.addEventListener(`resize`,u,{passive:!0});let f=new IntersectionObserver(([e])=>{l.offscreen=!e.isIntersecting,l.offscreen||(n.renderDirtyFrames=Math.max(n.renderDirtyFrames,2))});f.observe(c),n.renderDirtyFrames=Math.max(n.renderDirtyFrames,2),o(()=>{n.views.delete(a),d.disconnect(),f.disconnect(),window.removeEventListener(`scroll`,u,!0),window.removeEventListener(`resize`,u)})}),null}var $=[],Kt=[],qt=[],Jt=[];function Yt(e){$.push(e)}function Xt(){$.pop()}function Zt(){return $[$.length-1]??{}}function Qt(){return Kt[Kt.length-1]??{enabled:!1,aa:1}}function $t(){return qt[qt.length-1]??{}}function en(){return Jt[Jt.length-1]??null}var tn=0;function nn(){return`fabric-`+ ++tn}function rn(e){return typeof e==`function`?e():e}function an(e,t=0){return e===void 0?{x:t,y:t,z:t}:typeof e==`number`?{x:e,y:e,z:e}:Array.isArray(e)?{x:e[0]??t,y:e[1]??t,z:e[2]??t}:{x:e.x??t,y:e.y??t,z:e.z??t}}function on(e){return an(e)}function sn(e,t){let n=[],r=e=>{if(e){if(typeof e.on==`function`){n.push(e.on(`change`,t));return}if(typeof e==`function`&&typeof e.set==`function`&&typeof e.subscribe==`function`){n.push(e.subscribe(t));return}typeof e==`object`&&e&&!e.$$typeof&&Object.values(e).forEach(r)}};return r(e),()=>n.forEach(e=>e?.())}function cn(e){return[e?.ambient,e?.shader,e?.shininess,e?.steps,e?.smoothness,e?.highlightColor,e?.roughness,e?.roughnessScale,e?.grain,e?.grainScale,e?.grainType,e?.ior,e?.fresnel,e?.fresnelColor,e?.innerSteps,e?.chromaticAberration,e?.color,e?.outline,e?.thickness]}function ln(e){let{position:t,size:r,rotation:i,roundness:a=0,color:s,opacity:c=.9,material:l={ambient:.2},onClick:u,onPointerOver:d,onPointerOut:f}=e,p=M(),{shapesRef:m}=p,{outline:h,glow:g}=Zt(),_=Qt(),v=$t(),y=en(),b=nn(),x=an(t),S=on(i),C=an(r,2);return n(()=>{let t=p.gpu();if(!t)return;L(async()=>{let{initSDF:e}=await import(`./sdfEngine-USfrQfGe.js`);return{initSDF:e}},[]).then(({initSDF:e})=>{let t=p.gpuRef.current;t&&e(t)}),m.current.set(b,{type:0,position:x,size:C,rotation:S,roundness:a,color:s,opacity:c,material:l,outline:_.enabled?void 0:h,glow:_.enabled?void 0:g,fast:_.enabled,fastAA:_.enabled?_.aa:0,modifier:v,visibleGroup:y,onClick:u,onPointerOver:d,onPointerOut:f}),t.renderDirtyFrames=Math.max(t.renderDirtyFrames,2),cn(l);let n=sn({...e,outline:h,glow:g,modifier:v},()=>{t.renderDirtyFrames=Math.max(t.renderDirtyFrames,2)});o(()=>{n(),m.current.delete(b),t.renderDirtyFrames=Math.max(t.renderDirtyFrames,2)})}),null}function un({outline:e,glow:t,children:n}){Yt({outline:e,glow:t});try{return rn(n)}finally{Xt()}}var dn=typeof window<`u`&&window.devicePixelRatio>1,fn={fov:60,zoom:1,cameraZ:8,cameraMode:0,rigMode:0,warpStrength:3,warpRadius:4,pointerZ:0,pointerFalloff:0,easing:5,range:{x:2,y:1},zDolly:2,trackMouse:!0,trackDevice:!0},pn={speed:3,curl:.04,amplitude:0,distance:0,color:`#000`,focusColor:`#00ff0d`,pointsize:dn?6:3.5,gridSpacing:dn?.6:.4,resolution:64,highlightFocus:!1,useSlots:!1,slotRadius:.05,slotLength:1,slotSize:10,usePlyColor:!1,focus:8,aperture:5.6},mn={translateX:0,translateY:0,translateZ:0,rotationX:0,rotationY:0,rotationZ:0,showAxes:!1,fps:60,maxSteps:32,sdfEpsilon:.004,lodScaling:0,edgeSoftness:1,stepRelaxation:1,stats:!1,debugMode:!1,enableReflection:!1},hn={...pn,...mn};function gn({className:t,camera:n,scene:i}){if(typeof window>`u`)return null;let o=Ft(fn,hn),s={...fn,...n},c={...mn,...i},l=se(.2),u={};return a(r,{children:[e(zt,{...s}),e(Bt,{...c}),e(un,{glow:{intensity:l,color:`#00ff66`,radius:.2},children:()=>e(ln,{position:[1,-2,0],rotation:[u.cube3RotX??30,u.cube3RotY??30,u.cube3RotZ??0],size:{x:.6,y:.6,z:.6},roundness:.4,color:`#ef23db`,material:{ambient:.3,shader:`phong`,roughness:.004,roughnessScale:6}})}),e(Gt,{track:o}),e(`canvas`,{ref:o.canvas,class:t,style:{position:`absolute`,top:0,left:0,width:`100%`,height:`100%`}})]})}export{fe as a,re as i,L as n,Ne as r,gn as t};